package com.luandevsgame.spotflow

import android.content.Intent
import android.os.Handler
import android.os.Looper
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import kotlin.math.abs

class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { applyFade(); handler.postDelayed(this, 150) }
    }

    companion object {
        var exo: ExoPlayer? = null
        private val h = Handler(Looper.getMainLooper())
        private var sleepRunnable: Runnable? = null

        fun setSleepTimer(min: Int) {
            sleepRunnable?.let { h.removeCallbacks(it) }
            sleepRunnable = null
            if (min > 0) {
                val r = Runnable { exo?.pause(); Prefs.sleepMin = 0 }
                sleepRunnable = r
                h.postDelayed(r, min * 60_000L)
            }
        }
    }

    private fun applyFade() {
        val p = exo ?: return
        val f = Prefs.fadeSec * 1000L
        var v = 1f
        if (f > 0L) {
            val pos = p.currentPosition
            val dur = p.duration
            if (pos < f) v = minOf(v, pos.toFloat() / f)
            if (dur > 0 && dur - pos < f) v = minOf(v, (dur - pos).toFloat() / f)
        }
        v = v.coerceIn(0f, 1f)
        if (abs(p.volume - v) > 0.01f) p.volume = v
    }

    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(AudioAttributes.Builder().setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).setUsage(C.USAGE_MEDIA).build(), true)
            .setHandleAudioBecomingNoisy(true)
            .build()
        player.skipSilenceEnabled = Prefs.skipSilence
        player.setPlaybackSpeed(Prefs.speed)
        exo = player
        Eq.attach(player.audioSessionId)
        player.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) { Eq.attach(audioSessionId) }
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                handler.removeCallbacks(tick)
                if (isPlaying) handler.post(tick) else player.volume = 1f
            }
        })
        session = MediaSession.Builder(this, player).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo) = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        Eq.release()
        exo = null
        session?.run { player.release(); release() }
        session = null
        super.onDestroy()
    }
}
