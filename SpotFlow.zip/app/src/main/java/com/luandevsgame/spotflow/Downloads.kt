package com.luandevsgame.spotflow

import android.app.DownloadManager
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Environment
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class Tracked(val id: Long, val title: String, val url: String, val fileName: String)
data class DlState(val t: Tracked, val status: Int, val done: Long, val total: Long, val reason: Int, val local: String?)
data class JamTrack(val id: String, val name: String, val artist: String, val album: String, val durationSec: Int,
                    val image: String, val audioUrl: String, val downloadUrl: String, val allowed: Boolean)
data class IaItem(val id: String, val title: String, val creator: String)
data class IaFile(val name: String, val format: String, val size: Long)

val AUDIO_EXT = listOf(".mp3", ".m4a", ".aac", ".ogg", ".opus", ".flac", ".wav")

private fun getJson(url: String): JSONObject {
    val c = URL(url).openConnection() as HttpURLConnection
    c.setRequestProperty("User-Agent", "SpotFlow/0.1 (projeto pessoal)")
    c.connectTimeout = 10000; c.readTimeout = 20000
    try {
        if (c.responseCode != 200) error("O servidor respondeu ${c.responseCode}")
        return JSONObject(c.inputStream.bufferedReader().readText())
    } finally { c.disconnect() }
}

private fun str(o: Any?): String = when (o) { is JSONArray -> o.optString(0); null -> ""; else -> o.toString() }

/** Internet Archive: API pública documentada (advancedsearch + metadata). */
fun iaSearch(q: String): List<IaItem> {
    val query = URLEncoder.encode("($q) AND mediatype:audio", "UTF-8")
    val j = getJson("https://archive.org/advancedsearch.php?q=$query&fl%5B%5D=identifier&fl%5B%5D=title&fl%5B%5D=creator&sort%5B%5D=downloads+desc&rows=20&output=json")
    val docs = j.getJSONObject("response").getJSONArray("docs")
    return (0 until docs.length()).map { val d = docs.getJSONObject(it); IaItem(d.getString("identifier"), str(d.opt("title")), str(d.opt("creator"))) }
}

fun iaFiles(id: String): List<IaFile> {
    val arr = getJson("https://archive.org/metadata/" + Uri.encode(id)).optJSONArray("files") ?: return emptyList()
    return (0 until arr.length()).map { arr.getJSONObject(it) }
        .filter { f -> AUDIO_EXT.any { f.optString("name").lowercase().endsWith(it) } }
        .map { IaFile(it.optString("name"), it.optString("format"), it.optString("size").toLongOrNull() ?: 0L) }
        .take(40)
}

fun enqueue(ctx: Context, url: String, fileName: String, title: String): Long {
    val dm = ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
    val safe = fileName.substringAfterLast('/').replace(Regex("[\\\\/:*?\"<>|]"), "_")
    val req = DownloadManager.Request(Uri.parse(url)).setTitle(title)
        .setDestinationInExternalPublicDir(Environment.DIRECTORY_MUSIC, "SpotFlow/$safe")
        .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
    return dm.enqueue(req)
}

private fun queryStates(dm: DownloadManager, list: List<Tracked>): List<DlState> {
    val found = HashMap<Long, DlState>()
    val byId = list.associateBy { it.id }
    dm.query(DownloadManager.Query().setFilterById(*list.map { it.id }.toLongArray()))?.use { c ->
        while (c.moveToNext()) {
            val id = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_ID))
            val t = byId[id] ?: continue
            found[id] = DlState(t, c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)),
                c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)),
                c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)),
                c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON)),
                c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_LOCAL_URI)))
        }
    }
    return list.mapNotNull { found[it.id] }
}

private fun mb(b: Long) = "%.1f MB".format(b / 1048576.0)

private fun failText(reason: Int) = when {
    reason == DownloadManager.ERROR_INSUFFICIENT_SPACE -> "Sem espaço no aparelho."
    reason in 400..599 -> "O servidor respondeu $reason."
    else -> "Falha de rede ou arquivo incompleto (o arquivo parcial é descartado)."
}

/** Jamendo API v3.0 (oficial). Exige client_id próprio do usuário; só baixa quando audiodownload_allowed = true. */
fun jamendoSearch(key: String, q: String): List<JamTrack> {
    val url = "https://api.jamendo.com/v3.0/tracks/?client_id=" + URLEncoder.encode(key, "UTF-8") +
        "&format=json&limit=20&search=" + URLEncoder.encode(q, "UTF-8")
    val j = getJson(url)
    val h = j.optJSONObject("headers")
    if (h != null && h.optString("status") != "success") error(h.optString("error_message").ifBlank { "chave inválida ou erro da API" })
    val arr = j.optJSONArray("results") ?: return emptyList()
    return (0 until arr.length()).map { i ->
        val o = arr.getJSONObject(i)
        JamTrack(o.optString("id"), o.optString("name"), o.optString("artist_name"), o.optString("album_name"), o.optInt("duration"),
            o.optString("image"), o.optString("audio"), o.optString("audiodownload"), o.optBoolean("audiodownload_allowed", false))
    }
}

private val FORMAT_RANK = listOf("vbr mp3", "mp3", "128kbps mp3", "ogg vorbis", "opus", "64kbps mp3", "flac")

fun iaUrl(id: String, name: String) = "https://archive.org/download/${Uri.encode(id)}/${Uri.encode(name, "/")}"

/** Escolhe sozinho a faixa que mais combina com o que foi digitado, no melhor formato leve. */
fun bestFile(files: List<IaFile>, q: String): IaFile? {
    val words = q.lowercase().split(Regex("\\s+")).filter { it.length > 1 }
    fun score(f: IaFile) = words.count { f.name.lowercase().contains(it) }
    fun rank(f: IaFile): Int { val i = FORMAT_RANK.indexOf(f.format.lowercase()); return if (i < 0) 99 else i }
    return files.sortedWith(compareByDescending<IaFile> { score(it) }.thenBy { rank(it) }.thenBy { it.size }).firstOrNull()
}

@Composable
fun DownloadsScreen(refresh: () -> Unit, playStream: (MediaItem) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val uriHandler = LocalUriHandler.current
    val dm = remember { ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager }
    val tracked = remember { mutableStateListOf<Tracked>() }
    var states by remember { mutableStateOf<List<DlState>>(emptyList()) }
    val notified = remember { mutableSetOf<Long>() }
    var msg by remember { mutableStateOf<String?>(null) }
    var q by remember { mutableStateOf("") }
    var hits by remember { mutableStateOf<List<IaItem>>(emptyList()) }
    var jam by remember { mutableStateOf<List<JamTrack>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var busyId by remember { mutableStateOf<String?>(null) }
    var searched by remember { mutableStateOf(false) }
    var expanded by remember { mutableStateOf<String?>(null) }
    var files by remember { mutableStateOf<List<IaFile>>(emptyList()) }

    fun start(url: String, fileName: String, title: String) {
        try { tracked.add(0, Tracked(enqueue(ctx, url, fileName, title), title, url, fileName)); msg = "Download iniciado." }
        catch (e: Exception) { msg = "Não foi possível iniciar: ${e.message}" }
    }

    fun go() {
        if (q.isBlank()) return
        loading = true; expanded = null; msg = null
        scope.launch {
            val key = Prefs.jamendoKey.trim()
            var err: String? = null
            jam = if (key.isBlank()) emptyList() else try { withContext(Dispatchers.IO) { jamendoSearch(key, q.trim()) } }
                catch (e: Exception) { err = "Jamendo: ${e.message ?: "verifique a conexão"}"; emptyList() }
            hits = try { withContext(Dispatchers.IO) { iaSearch(q.trim()) } }
                catch (e: Exception) { err = (if (err != null) err + " | " else "") + "Internet Archive: ${e.message ?: "verifique a conexão"}"; emptyList() }
            searched = true
            msg = err
            loading = false
        }
    }

    /** Ouvir (streaming) ou baixar o melhor arquivo do resultado, sem precisar de link. */
    fun act(h: IaItem, download: Boolean) {
        busyId = h.id; msg = null
        scope.launch {
            try {
                val f = bestFile(withContext(Dispatchers.IO) { iaFiles(h.id) }, q)
                if (f == null) msg = "Este resultado não tem arquivo de áudio."
                else if (download) start(iaUrl(h.id, f.name), f.name, h.title)
                else {
                    playStream(MediaItem.Builder().setMediaId("ia:${h.id}/${f.name}").setUri(iaUrl(h.id, f.name))
                        .setMediaMetadata(MediaMetadata.Builder().setTitle(f.name.substringBeforeLast('.')).setArtist(h.creator.ifBlank { h.title })
                            .setArtworkUri(Uri.parse("https://archive.org/services/img/${h.id}")).build()).build())
                    msg = "Tocando online no player do app."
                }
            } catch (e: Exception) { msg = "Falha: ${e.message ?: "verifique a conexão"}" }
            busyId = null
        }
    }

    LaunchedEffect(Unit) {
        while (true) {
            val snap = tracked.toList()
            if (snap.isNotEmpty()) {
                val s = withContext(Dispatchers.IO) { queryStates(dm, snap) }
                s.filter { it.status == DownloadManager.STATUS_SUCCESSFUL && notified.add(it.t.id) }.forEach { d ->
                    val path = d.local?.let { Uri.parse(it).path }
                    if (path != null) MediaScannerConnection.scanFile(ctx, arrayOf(path), null) { _, _ -> refresh() }
                }
                states = s
            }
            delay(1000)
        }
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Downloads", fontSize = 28.sp, fontWeight = FontWeight.Bold) }
        item { Text("Digite o nome da música ou do artista: o app procura sozinho nas fontes que permitem download (Internet Archive: domínio público, Creative Commons, shows e gravações autorizadas). Músicas comerciais populares normalmente não estão lá. Baixe somente o que você tem direito de baixar.", color = Muted, fontSize = 12.sp) }
        item {
            OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), singleLine = true,
                placeholder = { Text("Nome da música ou artista") },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { go() }),
                trailingIcon = { IconButton({ go() }) { Icon(Icons.Filled.Search, "Pesquisar") } })
            if (loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 6.dp), color = Green)
        }
        if (Prefs.jamendoKey.isBlank()) item { Text("Para pesquisar também no Jamendo, adicione sua chave gratuita em Ajustes > Fontes de música.", color = Muted, fontSize = 12.sp) }
        msg?.let { item { Text(it, color = Green) } }
        items(jam, key = { "jam-" + it.id }) { t ->
            Column(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Cover(t.image, 52)
                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        Text(t.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(t.artist + (if (t.album.isNotBlank()) " • ${t.album}" else ""), maxLines = 1, overflow = TextOverflow.Ellipsis, color = Muted, fontSize = 12.sp)
                        Text("Jamendo (Creative Commons)" + (if (t.durationSec > 0) " • %d:%02d".format(t.durationSec / 60, t.durationSec % 60) else ""), color = Green, fontSize = 11.sp)
                    }
                }
                Row(Modifier.padding(start = 64.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (t.audioUrl.isNotBlank()) TextButton({
                        playStream(MediaItem.Builder().setMediaId("jam:${t.id}").setUri(t.audioUrl)
                            .setMediaMetadata(MediaMetadata.Builder().setTitle(t.name).setArtist(t.artist).setAlbumTitle(t.album)
                                .setArtworkUri(Uri.parse(t.image)).build()).build())
                        msg = "Tocando online no player do app."
                    }) { Text("Ouvir", color = Green) }
                    if (t.allowed && t.downloadUrl.isNotBlank()) TextButton({ start(t.downloadUrl, "${t.artist} - ${t.name}.mp3", t.name) }) { Text("Baixar", color = Green) }
                    else Text("Download não permitido pelo artista", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(start = 8.dp))
                }
            }
        }
        items(hits, key = { "ia-" + it.id }) { h ->
            Column(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Cover("https://archive.org/services/img/${h.id}", 52)
                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        Text(h.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(h.creator.ifBlank { "Autor não informado" } + " • Internet Archive", maxLines = 1, overflow = TextOverflow.Ellipsis, color = Muted, fontSize = 12.sp)
                    }
                }
                Row(Modifier.padding(start = 64.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (busyId == h.id) CircularProgressIndicator(Modifier.size(20.dp), color = Green, strokeWidth = 2.dp)
                    else {
                        TextButton({ act(h, false) }) { Text("Ouvir", color = Green) }
                        TextButton({ act(h, true) }) { Text("Baixar", color = Green) }
                        TextButton({
                            if (expanded == h.id) expanded = null else {
                                expanded = h.id; files = emptyList()
                                scope.launch {
                                    try { files = withContext(Dispatchers.IO) { iaFiles(h.id) }; if (files.isEmpty()) msg = "Este item não tem arquivos de áudio." }
                                    catch (e: Exception) { msg = "Falha ao listar arquivos: ${e.message ?: "verifique a conexão"}" }
                                }
                            }
                        }) { Text(if (expanded == h.id) "Fechar" else "Formatos", color = Muted) }
                    }
                }
                if (expanded == h.id) files.forEach { f ->
                    Row(Modifier.fillMaxWidth().padding(start = 64.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp)
                            Text(f.format + if (f.size > 0) " • ${mb(f.size)}" else "", color = Muted, fontSize = 11.sp)
                        }
                        TextButton({ start(iaUrl(h.id, f.name), f.name, h.title) }) { Text("Baixar", color = Green) }
                    }
                }
            }
        }
        if (searched) item {
            Column {
                Text(if (hits.isEmpty() && jam.isEmpty()) "Nada encontrado nas fontes que permitem download." else "Não achou a faixa que queria?", color = Muted, fontSize = 12.sp)
                TextButton({ uriHandler.openUri("https://music.youtube.com/search?q=" + Uri.encode(q.trim())) }) {
                    Text("Abrir no YouTube Music (apenas abre, não baixa)", color = Green)
                }
            }
        }
        item { Text("Fila e histórico (desta sessão)", fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp)) }
        items(states, key = { "dl-" + it.t.id }) { d ->
            Column(Modifier.fillMaxWidth()) {
                Text(d.t.fileName, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                val active = d.status == DownloadManager.STATUS_RUNNING || d.status == DownloadManager.STATUS_PENDING || d.status == DownloadManager.STATUS_PAUSED
                when (d.status) {
                    DownloadManager.STATUS_SUCCESSFUL -> Text("Concluído e adicionado à biblioteca • ${mb(d.done)}", color = Green, fontSize = 12.sp)
                    DownloadManager.STATUS_FAILED -> Text(failText(d.reason), color = Color(0xFFFF6B6B), fontSize = 12.sp)
                    else -> {
                        if (d.total > 0) LinearProgressIndicator({ d.done.toFloat() / d.total }, Modifier.fillMaxWidth(), color = Green)
                        else LinearProgressIndicator(Modifier.fillMaxWidth(), color = Green)
                        Text((if (d.status == DownloadManager.STATUS_PAUSED) "Pausado (aguardando rede) • " else "") +
                            if (d.total > 0) "${d.done * 100 / d.total}% • ${mb(d.done)} de ${mb(d.total)}" else mb(d.done), color = Muted, fontSize = 12.sp)
                    }
                }
                Row {
                    if (active) TextButton({ dm.remove(d.t.id); tracked.removeAll { it.id == d.t.id }; states = states.filter { it.t.id != d.t.id } }) { Text("Cancelar", color = Muted) }
                    if (d.status == DownloadManager.STATUS_FAILED) TextButton({
                        dm.remove(d.t.id)
                        val i = tracked.indexOfFirst { it.id == d.t.id }
                        try { val nid = enqueue(ctx, d.t.url, d.t.fileName, d.t.title); if (i >= 0) tracked[i] = d.t.copy(id = nid) }
                        catch (e: Exception) { msg = "Não foi possível tentar de novo: ${e.message}" }
                    }) { Text("Tentar de novo", color = Green) }
                }
            }
        }
    }
}
