package com.luandevsgame.spotflow

import android.content.Context
import android.content.SharedPreferences
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

object Prefs {
    var sp: SharedPreferences? = null
    var accent by mutableIntStateOf(0)
    var fadeSec by mutableIntStateOf(0)
    var skipSilence by mutableStateOf(false)
    var speed by mutableFloatStateOf(1f)
    var sleepMin by mutableIntStateOf(0)
    var jamendoKey by mutableStateOf("")
    val accents = listOf(
        "Verde" to Color(0xFF2BE36B), "Azul" to Color(0xFF3EA6FF), "Laranja" to Color(0xFFFF9F43),
        "Roxo" to Color(0xFFB388FF), "Rosa" to Color(0xFFFF6FA5))

    fun init(ctx: Context) {
        if (sp != null) return
        val s = ctx.applicationContext.getSharedPreferences("musicflow", Context.MODE_PRIVATE)
        sp = s
        accent = s.getInt("accent", 0).coerceIn(0, accents.size - 1)
        fadeSec = s.getInt("fade", 0).coerceIn(0, 10)
        skipSilence = s.getBoolean("skip", false)
        speed = s.getFloat("speed", 1f)
        jamendoKey = s.getString("jamendo", "") ?: ""
    }

    fun save() {
        sp?.edit()?.putInt("accent", accent)?.putInt("fade", fadeSec)?.putBoolean("skip", skipSilence)?.putFloat("speed", speed)?.putString("jamendo", jamendoKey)?.apply()
    }
}

/** Equalizador do Android ligado à sessão de áudio do player (mesmo processo do serviço). */
object Eq {
    private var eq: Equalizer? = null
    private var bass: BassBoost? = null
    var available by mutableStateOf(false)
    var enabled by mutableStateOf(false)
    var levels by mutableStateOf<List<Int>>(emptyList())
    var freqs by mutableStateOf<List<String>>(emptyList())
    var presets by mutableStateOf<List<String>>(emptyList())
    var minLevel by mutableIntStateOf(-1500)
    var maxLevel by mutableIntStateOf(1500)
    var bassOk by mutableStateOf(false)
    var bassStrength by mutableIntStateOf(0)

    fun attach(session: Int) {
        release()
        try {
            val e = Equalizer(0, session)
            val n = e.numberOfBands.toInt()
            val r = e.bandLevelRange
            minLevel = r[0].toInt(); maxLevel = r[1].toInt()
            freqs = (0 until n).map { b ->
                val hz = e.getCenterFreq(b.toShort()) / 1000
                if (hz >= 1000) "%.1fk".format(hz / 1000f) else "$hz"
            }
            presets = (0 until e.numberOfPresets.toInt()).map { e.getPresetName(it.toShort()) }
            val saved = Prefs.sp?.getString("eq_levels", null)?.split(",")?.mapNotNull { it.toIntOrNull() }
            val lv = if (saved != null && saved.size == n) saved else (0 until n).map { e.getBandLevel(it.toShort()).toInt() }
            lv.forEachIndexed { i, l -> e.setBandLevel(i.toShort(), l.toShort()) }
            levels = lv
            enabled = Prefs.sp?.getBoolean("eq_on", false) ?: false
            e.enabled = enabled
            eq = e
            try {
                val b = BassBoost(0, session)
                bassOk = b.strengthSupported
                bassStrength = Prefs.sp?.getInt("bass", 0) ?: 0
                if (bassOk) { b.setStrength(bassStrength.toShort()); b.enabled = enabled && bassStrength > 0 }
                bass = b
            } catch (x: Exception) { bassOk = false }
            available = true
        } catch (x: Exception) { available = false }
    }

    fun release() {
        try { eq?.release() } catch (x: Exception) { }
        try { bass?.release() } catch (x: Exception) { }
        eq = null; bass = null; available = false
    }

    private fun save() {
        Prefs.sp?.edit()?.putBoolean("eq_on", enabled)?.putString("eq_levels", levels.joinToString(","))?.putInt("bass", bassStrength)?.apply()
    }

    fun setEnabled(on: Boolean) {
        enabled = on; eq?.enabled = on
        bass?.let { if (bassOk) it.enabled = on && bassStrength > 0 }
        save()
    }

    fun setLevel(i: Int, mb: Int) {
        val l = levels.toMutableList(); if (i !in l.indices) return
        l[i] = mb; levels = l
        eq?.setBandLevel(i.toShort(), mb.toShort()); save()
    }

    fun usePreset(i: Int) {
        val e = eq ?: return
        e.usePreset(i.toShort())
        levels = (0 until levels.size).map { e.getBandLevel(it.toShort()).toInt() }
        save()
    }

    fun setBass(v: Int) {
        bassStrength = v
        bass?.let { if (bassOk) { it.setStrength(v.toShort()); it.enabled = enabled && v > 0 } }
        save()
    }
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) = Column {
    Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Green)
    Spacer(Modifier.height(8.dp))
    content()
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) =
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked, onChange, colors = SwitchDefaults.colors(checkedTrackColor = Green, checkedThumbColor = Color.Black))
    }

@Composable
fun SettingsScreen() {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(22.dp)) {
        item { Text("Ajustes", fontSize = 28.sp, fontWeight = FontWeight.Bold) }

        item {
            val uri = LocalUriHandler.current
            Section("Fontes de música") {
                Text("Jamendo (catálogo de música independente com licença Creative Commons; cada artista decide se permite download). Cole sua chave gratuita (client_id) para pesquisar por nome na aba Downloads. A chave fica só neste aparelho.", color = Muted, fontSize = 12.sp)
                OutlinedTextField(Prefs.jamendoKey, { Prefs.jamendoKey = it.trim(); Prefs.save() }, Modifier.fillMaxWidth().padding(top = 6.dp),
                    singleLine = true, placeholder = { Text("client_id do Jamendo") })
                TextButton({ uri.openUri("https://devportal.jamendo.com") }) { Text("Obter chave gratuita", color = Green) }
            }
        }

        item {
            Section("Aparência") {
                Text("Cor de destaque", color = Muted, fontSize = 13.sp)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    itemsIndexed(Prefs.accents) { i, a ->
                        FilterChip(Prefs.accent == i, { Prefs.accent = i; Prefs.save() }, { Text(a.first) })
                    }
                }
            }
        }

        item {
            Section("Reprodução") {
                Text("Fade entre músicas: " + (if (Prefs.fadeSec == 0) "desligado" else "${Prefs.fadeSec} s"), color = Muted, fontSize = 13.sp)
                Slider(Prefs.fadeSec.toFloat(), { Prefs.fadeSec = it.roundToInt() }, valueRange = 0f..10f, steps = 9,
                    onValueChangeFinished = { Prefs.save() },
                    colors = SliderDefaults.colors(thumbColor = Green, activeTrackColor = Green))
                Text("A música entra e sai suavemente (fade in/out). Não sobrepõe duas faixas.", color = Muted, fontSize = 11.sp)
                Spacer(Modifier.height(10.dp))
                SwitchRow("Pular silêncios", Prefs.skipSilence) {
                    Prefs.skipSilence = it; Prefs.save(); PlaybackService.exo?.skipSilenceEnabled = it
                }
                Spacer(Modifier.height(10.dp))
                Text("Velocidade", color = Muted, fontSize = 13.sp)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    itemsIndexed(listOf(0.75f, 1f, 1.25f, 1.5f, 2f)) { _, v ->
                        FilterChip(Prefs.speed == v, { Prefs.speed = v; Prefs.save(); PlaybackService.exo?.setPlaybackSpeed(v) }, { Text("${v}x") })
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text("Timer para dormir", color = Muted, fontSize = 13.sp)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    itemsIndexed(listOf(0, 15, 30, 60)) { _, m ->
                        FilterChip(Prefs.sleepMin == m, { Prefs.sleepMin = m; PlaybackService.setSleepTimer(m) },
                            { Text(if (m == 0) "Desligado" else "$m min") })
                    }
                }
            }
        }

        item {
            Section("Equalizador") {
                if (!Eq.available) {
                    Text("Equalizador indisponível neste aparelho ou o player ainda não iniciou. Abra uma música e volte aqui.", color = Muted, fontSize = 13.sp)
                } else {
                    SwitchRow("Ativar equalizador", Eq.enabled) { Eq.setEnabled(it) }
                    if (Eq.presets.isNotEmpty()) {
                        Spacer(Modifier.height(6.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            itemsIndexed(Eq.presets) { i, n -> FilterChip(false, { Eq.usePreset(i) }, { Text(n) }, enabled = Eq.enabled) }
                        }
                    }
                    Eq.levels.forEachIndexed { i, l ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(Eq.freqs.getOrElse(i) { "" } + " Hz", Modifier.width(72.dp), fontSize = 12.sp, color = Muted)
                            Slider(l.toFloat(), { Eq.setLevel(i, it.toInt()) }, enabled = Eq.enabled,
                                valueRange = Eq.minLevel.toFloat()..Eq.maxLevel.toFloat(),
                                colors = SliderDefaults.colors(thumbColor = Green, activeTrackColor = Green))
                        }
                    }
                    if (Eq.bassOk) {
                        Text("Reforço de graves", color = Muted, fontSize = 13.sp)
                        Slider(Eq.bassStrength.toFloat(), { Eq.setBass(it.toInt()) }, enabled = Eq.enabled, valueRange = 0f..1000f,
                            colors = SliderDefaults.colors(thumbColor = Green, activeTrackColor = Green))
                    }
                }
            }
        }
    }
}
