package com.luandevsgame.spotflow

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import kotlinx.coroutines.delay

private fun fmt(ms: Long): String = "%d:%02d".format(ms / 60000, ms / 1000 % 60)

@Composable
fun NowPlayingOverlay(visible: Boolean, ps: PlayerState, c: MediaController, onClose: () -> Unit) {
    BackHandler(enabled = visible, onBack = onClose)
    AnimatedVisibility(visible = visible, enter = slideInVertically { it }, exit = slideOutVertically { it }) {
        NowPlayingScreen(ps, c, onClose)
    }
}

@Composable
fun NowPlayingScreen(ps: PlayerState, c: MediaController, onClose: () -> Unit) {
    var pos by remember { mutableFloatStateOf(0f) }
    var dragging by remember { mutableStateOf(false) }
    LaunchedEffect(ps.title) {
        while (true) { if (!dragging) pos = c.currentPosition.toFloat(); delay(500) }
    }
    val dur = c.duration.coerceAtLeast(1L).toFloat()

    Column(
        Modifier.fillMaxSize().background(Color(0xFF121212))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
            .padding(horizontal = 24.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) { Icon(Icons.Filled.KeyboardArrowDown, "Fechar") }
            Text("Tocando agora", modifier = Modifier.weight(1f), textAlign = TextAlign.Center, color = Muted, fontSize = 13.sp)
            Spacer(Modifier.width(48.dp))
        }
        Spacer(Modifier.height(20.dp))
        PlayerCover(ps, Modifier.fillMaxWidth().aspectRatio(1f), 16.dp)
        Spacer(Modifier.height(28.dp))
        Text(ps.title, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
        Text(ps.artist, color = Muted, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
        Spacer(Modifier.height(20.dp))
        Slider(
            value = pos.coerceIn(0f, dur),
            onValueChange = { dragging = true; pos = it },
            valueRange = 0f..dur,
            onValueChangeFinished = { c.seekTo(pos.toLong()); dragging = false },
            modifier = Modifier.fillMaxWidth(),
            colors = SliderDefaults.colors(thumbColor = Green, activeTrackColor = Green)
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(fmt(pos.toLong()), color = Muted, fontSize = 12.sp)
            Text(fmt(c.duration.coerceAtLeast(0L)), color = Muted, fontSize = 12.sp)
        }
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { c.shuffleModeEnabled = !c.shuffleModeEnabled }) {
                Icon(Icons.Filled.Shuffle, "Aleatório", tint = if (ps.shuffle) Green else Muted)
            }
            IconButton(onClick = { c.seekToPrevious() }) { Icon(Icons.Filled.SkipPrevious, "Anterior", modifier = Modifier.size(40.dp)) }
            FilledIconButton(onClick = { if (c.isPlaying) c.pause() else c.play() }, modifier = Modifier.size(72.dp),
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = Green, contentColor = Color.Black)) {
                Icon(if (ps.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Tocar/Pausar", modifier = Modifier.size(40.dp))
            }
            IconButton(onClick = { c.seekToNext() }) { Icon(Icons.Filled.SkipNext, "Próxima", modifier = Modifier.size(40.dp)) }
            IconButton(onClick = {
                c.repeatMode = when (c.repeatMode) {
                    Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                    Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                    else -> Player.REPEAT_MODE_OFF
                }
            }) {
                Icon(if (ps.repeat == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat, "Repetir",
                    tint = if (ps.repeat == Player.REPEAT_MODE_OFF) Muted else Green)
            }
        }
    }
}
